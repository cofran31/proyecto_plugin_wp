<?php

function acerca_de() {
    echo '<hr/>';
    echo '<center><img src="../wp-content/plugins/the-quiz-free/admin/img/quiz-plugins.jpg">';
    echo '<hr/>';
    echo "<h1>By. Juan Carlos Ortube </h1>";
    echo '</center><br/><br/>';
    echo '<h2> Este plugin te permite insertar tus encuestas directamente en tus POST . </h2>';
    echo '<ul><li><h2>* Simplemente copia el ID de la categoria que quieres mostrar por ejemplo: </h2></li>';
    echo '<center><img src="../wp-content/plugins/the-quiz-free/admin/img/uno.png"></center>';
    echo '<ul><li><h2>* Coloca el siguiente Tag en tu POST por ejemplo: </h2></li>';
    echo '<center><img src="../wp-content/plugins/the-quiz-free/admin/img/dos.png"></center>';
    echo '<ul><li><h2>* Listo ya tendras tu encuesta en tu pagina web. </h2></li>';
    echo '<center><img src="../wp-content/plugins/the-quiz-free/admin/img/tres.png"></center></ul>';
}

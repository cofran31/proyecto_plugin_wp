<?php

function acerca_de() {
    echo "este es miplugiinad asdasdasdad a das das das dasdad asdasdasda";
}
